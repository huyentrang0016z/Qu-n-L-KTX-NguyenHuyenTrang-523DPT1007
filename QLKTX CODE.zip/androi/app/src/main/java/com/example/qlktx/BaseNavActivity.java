package com.example.qlktx;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BaseNavActivity extends AppCompatActivity {

    private final int ACTIVE_COLOR = Color.parseColor("#0B6BFF");
    private final int INACTIVE_COLOR = Color.parseColor("#94A3B8");

    protected void setupBottomNav() {
        View navHome = findViewById(R.id.navHome);
        View navRoom = findViewById(R.id.navRoom);
        View navPayment = findViewById(R.id.navPayment);
        View navNotification = findViewById(R.id.navNotification);
        View navProfile = findViewById(R.id.navProfile);

        if (navHome != null) {
            navHome.setOnClickListener(v -> {
                if (!(this instanceof MainActivity)) {
                    openScreen(MainActivity.class);
                }
            });
        }

        if (navRoom != null) {
            navRoom.setOnClickListener(v -> {
                if (!(this instanceof RoomActivity)) {
                    openScreen(RoomActivity.class);
                }
            });
        }

        if (navPayment != null) {
            navPayment.setOnClickListener(v -> {
                if (!(this instanceof PaymentActivity)) {
                    openScreen(PaymentActivity.class);
                }
            });
        }

        if (navNotification != null) {
            navNotification.setOnClickListener(v -> {
                if (!(this instanceof NotificationActivity)) {
                    openScreen(NotificationActivity.class);
                }
            });
        }

        if (navProfile != null) {
            navProfile.setOnClickListener(v -> {
                if (!(this instanceof ProfileActivity)) {
                    openScreen(ProfileActivity.class);
                }
            });
        }

        updateActiveBottomNav();
    }

    protected void openScreen(Class<?> targetActivity) {
        Intent intent = new Intent(this, targetActivity);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    private void updateActiveBottomNav() {
        resetAllBottomNav();

        if (this instanceof MainActivity) {
            setActive(R.id.iconHome, R.id.textHome);
        } else if (this instanceof RoomActivity) {
            setActive(R.id.iconRoom, R.id.textRoom);
        } else if (
                this instanceof PaymentActivity ||
                        this instanceof PaymentDetailActivity ||
                        this instanceof PaymentMethodActivity ||
                        this instanceof PaymentResultActivity
        ) {
            setActive(R.id.iconPayment, R.id.textPayment);
        } else if (this instanceof NotificationActivity) {
            setActive(R.id.iconNotification, R.id.textNotification);
        } else if (this instanceof ProfileActivity) {
            setActive(R.id.iconProfile, R.id.textProfile);
        }
    }

    private void resetAllBottomNav() {
        setInactive(R.id.iconHome, R.id.textHome);
        setInactive(R.id.iconRoom, R.id.textRoom);
        setInactive(R.id.iconPayment, R.id.textPayment);
        setInactive(R.id.iconNotification, R.id.textNotification);
        setInactive(R.id.iconProfile, R.id.textProfile);
    }

    private void setActive(int iconId, int textId) {
        ImageView icon = findViewById(iconId);
        TextView text = findViewById(textId);

        if (icon != null) {
            icon.setColorFilter(ACTIVE_COLOR);
        }

        if (text != null) {
            text.setTextColor(ACTIVE_COLOR);
            text.setTypeface(null, Typeface.BOLD);
        }
    }

    private void setInactive(int iconId, int textId) {
        ImageView icon = findViewById(iconId);
        TextView text = findViewById(textId);

        if (icon != null) {
            icon.setColorFilter(INACTIVE_COLOR);
        }

        if (text != null) {
            text.setTextColor(INACTIVE_COLOR);
            text.setTypeface(null, Typeface.NORMAL);
        }
    }
}