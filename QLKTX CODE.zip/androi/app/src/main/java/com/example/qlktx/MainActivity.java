package com.example.qlktx;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupBottomNav();

        findViewById(R.id.cardRoom).setOnClickListener(v -> openScreen(RoomActivity.class));

        findViewById(R.id.cardPayment).setOnClickListener(v -> openScreen(PaymentActivity.class));

        findViewById(R.id.cardNoti).setOnClickListener(v -> openScreen(NotificationActivity.class));

        findViewById(R.id.cardRepair).setOnClickListener(v -> openScreen(RepairRequestActivity.class));

        findViewById(R.id.cardProfileHome).setOnClickListener(v -> openScreen(ProfileActivity.class));

        findViewById(R.id.btnBellHome).setOnClickListener(v -> openScreen(NotificationActivity.class));

        findViewById(R.id.txtSeeAllNoti).setOnClickListener(v -> openScreen(NotificationActivity.class));

        findViewById(R.id.cardRules).setOnClickListener(v -> {
            openScreen(RulesActivity.class);
        });

        findViewById(R.id.cardContact).setOnClickListener(v ->
                Toast.makeText(this, "Liên hệ quản lý KTX: 0901 234 567", Toast.LENGTH_SHORT).show()
        );
    }
}