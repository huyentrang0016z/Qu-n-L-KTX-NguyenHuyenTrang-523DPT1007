package com.example.qlktx;

import android.os.Bundle;

public class NotificationActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        setupBottomNav();

        findViewById(R.id.btnBackNotification).setOnClickListener(v -> {
            openScreen(MainActivity.class);
        });
    }
}