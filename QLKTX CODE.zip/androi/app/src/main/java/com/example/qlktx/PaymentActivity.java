package com.example.qlktx;

import android.os.Bundle;

public class PaymentActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        setupBottomNav();

        findViewById(R.id.btnBackPayment).setOnClickListener(v -> {
            openScreen(MainActivity.class);
        });

        findViewById(R.id.btnPayNow).setOnClickListener(v -> {
            openScreen(PaymentDetailActivity.class);
        });

        findViewById(R.id.txtGoRepairFromPayment).setOnClickListener(v -> {
            openScreen(RepairRequestActivity.class);
        });

        findViewById(R.id.cardRepairLight).setOnClickListener(v -> {
            openScreen(RepairRequestActivity.class);
        });

        findViewById(R.id.cardRepairAc).setOnClickListener(v -> {
            openScreen(RepairRequestActivity.class);
        });

        findViewById(R.id.cardRepairWater).setOnClickListener(v -> {
            openScreen(RepairRequestActivity.class);
        });
    }
}