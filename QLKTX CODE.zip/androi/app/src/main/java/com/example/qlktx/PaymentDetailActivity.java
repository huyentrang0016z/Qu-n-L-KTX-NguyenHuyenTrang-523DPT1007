package com.example.qlktx;

import android.os.Bundle;

public class PaymentDetailActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_detail);

        setupBottomNav();

        findViewById(R.id.btnBackPaymentDetail).setOnClickListener(v -> {
            openScreen(PaymentActivity.class);
        });

        findViewById(R.id.btnChoosePaymentMethod).setOnClickListener(v -> {
            openScreen(PaymentMethodActivity.class);
        });
    }
}