package com.example.qlktx;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

public class PaymentMethodActivity extends BaseNavActivity {

    TextView radioQr, radioMomo, radioZalo, radioBank;
    String selectedMethod = "QR Code";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method);

        setupBottomNav();

        radioQr = findViewById(R.id.radioQr);
        radioMomo = findViewById(R.id.radioMomo);
        radioZalo = findViewById(R.id.radioZalo);
        radioBank = findViewById(R.id.radioBank);

        findViewById(R.id.btnBackPaymentMethod).setOnClickListener(v -> {
            openScreen(PaymentDetailActivity.class);
        });

        findViewById(R.id.methodQr).setOnClickListener(v -> selectMethod("QR Code"));
        findViewById(R.id.methodMomo).setOnClickListener(v -> selectMethod("Ví MoMo"));
        findViewById(R.id.methodZalo).setOnClickListener(v -> selectMethod("ZaloPay"));
        findViewById(R.id.methodBank).setOnClickListener(v -> selectMethod("Ngân hàng / Internet Banking"));

        findViewById(R.id.btnContinuePayment).setOnClickListener(v -> {
            openScreen(PaymentResultActivity.class);
        });
    }

    private void selectMethod(String method) {
        selectedMethod = method;

        findViewById(R.id.methodQr).setBackgroundResource(R.drawable.bg_method_normal);
        findViewById(R.id.methodMomo).setBackgroundResource(R.drawable.bg_method_normal);
        findViewById(R.id.methodZalo).setBackgroundResource(R.drawable.bg_method_normal);
        findViewById(R.id.methodBank).setBackgroundResource(R.drawable.bg_method_normal);

        radioQr.setText("○");
        radioMomo.setText("○");
        radioZalo.setText("○");
        radioBank.setText("○");

        radioQr.setTextColor(getResources().getColor(R.color.text_gray));
        radioMomo.setTextColor(getResources().getColor(R.color.text_gray));
        radioZalo.setTextColor(getResources().getColor(R.color.text_gray));
        radioBank.setTextColor(getResources().getColor(R.color.text_gray));

        radioQr.setTypeface(null, Typeface.NORMAL);
        radioMomo.setTypeface(null, Typeface.NORMAL);
        radioZalo.setTypeface(null, Typeface.NORMAL);
        radioBank.setTypeface(null, Typeface.NORMAL);

        if (method.equals("QR Code")) {
            findViewById(R.id.methodQr).setBackgroundResource(R.drawable.bg_method_selected);
            radioQr.setText("●");
            radioQr.setTextColor(getResources().getColor(R.color.blue));
            radioQr.setTypeface(null, Typeface.BOLD);
        } else if (method.equals("Ví MoMo")) {
            findViewById(R.id.methodMomo).setBackgroundResource(R.drawable.bg_method_selected);
            radioMomo.setText("●");
            radioMomo.setTextColor(getResources().getColor(R.color.blue));
            radioMomo.setTypeface(null, Typeface.BOLD);
        } else if (method.equals("ZaloPay")) {
            findViewById(R.id.methodZalo).setBackgroundResource(R.drawable.bg_method_selected);
            radioZalo.setText("●");
            radioZalo.setTextColor(getResources().getColor(R.color.blue));
            radioZalo.setTypeface(null, Typeface.BOLD);
        } else {
            findViewById(R.id.methodBank).setBackgroundResource(R.drawable.bg_method_selected);
            radioBank.setText("●");
            radioBank.setTextColor(getResources().getColor(R.color.blue));
            radioBank.setTypeface(null, Typeface.BOLD);
        }
    }
}