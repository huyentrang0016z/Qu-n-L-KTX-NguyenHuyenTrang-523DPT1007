package com.example.qlktx;

import android.os.Bundle;
import android.widget.Toast;

public class PaymentResultActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_result);

        setupBottomNav();

        findViewById(R.id.btnViewReceipt).setOnClickListener(v -> {
            Toast.makeText(this, "Biên lai thanh toán HD052025A101", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnBackToPayment).setOnClickListener(v -> {
            openScreen(PaymentActivity.class);
        });
    }
}