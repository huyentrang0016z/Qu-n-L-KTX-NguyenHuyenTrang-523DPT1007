package com.example.qlktx;

import android.os.Bundle;

public class ProfileActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        setupBottomNav();

        findViewById(R.id.btnBackProfile).setOnClickListener(v -> {
            openScreen(MainActivity.class);
        });

        findViewById(R.id.btnEditProfile).setOnClickListener(v -> {
            openScreen(EditProfileActivity.class);
        });
    }
}