package com.example.qlktx;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    TextView btnBackRegister, btnCreateAccount, txtGoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnBackRegister = findViewById(R.id.btnBackRegister);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        txtGoLogin = findViewById(R.id.txtGoLogin);

        btnBackRegister.setOnClickListener(v -> finish());
        txtGoLogin.setOnClickListener(v -> finish());
        btnCreateAccount.setOnClickListener(v -> {
            Toast.makeText(this, "Tạo tài khoản thành công", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}
