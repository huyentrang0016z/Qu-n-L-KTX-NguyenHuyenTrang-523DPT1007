package com.example.qlktx;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RepairRequestActivity extends AppCompatActivity {

    TextView chipDien, chipNuoc, chipMayLanh, chipNoiThat;
    TextView btnPriorityNormal, btnPriorityUrgent;
    TextView btnSubmitRepair, btnBackRepair;

    String selectedIssueType = "Điện";
    String selectedPriority = "Thường";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repair_request);

        chipDien = findViewById(R.id.chipDien);
        chipNuoc = findViewById(R.id.chipNuoc);
        chipMayLanh = findViewById(R.id.chipMayLanh);
        chipNoiThat = findViewById(R.id.chipNoiThat);

        btnPriorityNormal = findViewById(R.id.btnPriorityNormal);
        btnPriorityUrgent = findViewById(R.id.btnPriorityUrgent);

        btnSubmitRepair = findViewById(R.id.btnSubmitRepair);
        btnBackRepair = findViewById(R.id.btnBackRepair);

        chipDien.setOnClickListener(v -> selectIssueType("Điện"));
        chipNuoc.setOnClickListener(v -> selectIssueType("Nước"));
        chipMayLanh.setOnClickListener(v -> selectIssueType("Máy lạnh"));
        chipNoiThat.setOnClickListener(v -> selectIssueType("Nội thất"));

        btnPriorityNormal.setOnClickListener(v -> selectPriority("Thường"));
        btnPriorityUrgent.setOnClickListener(v -> selectPriority("Khẩn cấp"));

        btnBackRepair.setOnClickListener(v -> finish());

        btnSubmitRepair.setOnClickListener(v -> {
            Toast.makeText(
                    this,
                    "Đã gửi yêu cầu: " + selectedIssueType + " - " + selectedPriority,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
        });
    }

    private void selectIssueType(String type) {
        selectedIssueType = type;

        chipDien.setBackgroundResource(R.drawable.bg_chip_yellow);
        chipNuoc.setBackgroundResource(R.drawable.bg_chip_blue);
        chipMayLanh.setBackgroundResource(R.drawable.bg_chip_purple);
        chipNoiThat.setBackgroundResource(R.drawable.bg_chip_green);

        chipDien.setTypeface(null, Typeface.NORMAL);
        chipNuoc.setTypeface(null, Typeface.NORMAL);
        chipMayLanh.setTypeface(null, Typeface.NORMAL);
        chipNoiThat.setTypeface(null, Typeface.NORMAL);

        if (type.equals("Điện")) {
            chipDien.setBackgroundResource(R.drawable.bg_chip_yellow_selected);
            chipDien.setTypeface(null, Typeface.BOLD);
        } else if (type.equals("Nước")) {
            chipNuoc.setBackgroundResource(R.drawable.bg_chip_blue_selected);
            chipNuoc.setTypeface(null, Typeface.BOLD);
        } else if (type.equals("Máy lạnh")) {
            chipMayLanh.setBackgroundResource(R.drawable.bg_chip_purple_selected);
            chipMayLanh.setTypeface(null, Typeface.BOLD);
        } else if (type.equals("Nội thất")) {
            chipNoiThat.setBackgroundResource(R.drawable.bg_chip_green_selected);
            chipNoiThat.setTypeface(null, Typeface.BOLD);
        }
    }

    private void selectPriority(String priority) {
        selectedPriority = priority;

        btnPriorityNormal.setBackgroundResource(R.drawable.bg_priority_normal);
        btnPriorityUrgent.setBackgroundResource(R.drawable.bg_priority_danger);

        btnPriorityNormal.setTypeface(null, Typeface.NORMAL);
        btnPriorityUrgent.setTypeface(null, Typeface.NORMAL);

        btnPriorityNormal.setText("Thường");
        btnPriorityUrgent.setText("Khẩn cấp");

        if (priority.equals("Thường")) {
            btnPriorityNormal.setBackgroundResource(R.drawable.bg_priority_selected);
            btnPriorityNormal.setTypeface(null, Typeface.BOLD);
            btnPriorityNormal.setText("● Thường");
        } else {
            btnPriorityUrgent.setBackgroundResource(R.drawable.bg_priority_danger_selected);
            btnPriorityUrgent.setTypeface(null, Typeface.BOLD);
            btnPriorityUrgent.setText("● Khẩn cấp");
        }
    }
}