package com.example.qlktx;

import android.os.Bundle;

public class RoomActivity extends BaseNavActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);

        setupBottomNav();

        // Bấm mũi tên quay về Trang chủ
        findViewById(R.id.btnBackRoom).setOnClickListener(v -> {
            openScreen(MainActivity.class);
        });

        // Bấm nút Báo sự cố sang màn Yêu cầu sửa chữa
        findViewById(R.id.btnReportProblem).setOnClickListener(v -> {
            openScreen(RepairRequestActivity.class);
        });
    }
}