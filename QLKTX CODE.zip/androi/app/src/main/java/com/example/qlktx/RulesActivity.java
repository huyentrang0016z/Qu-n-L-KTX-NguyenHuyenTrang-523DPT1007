package com.example.qlktx;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RulesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);

        findViewById(R.id.btnBackRules).setOnClickListener(v -> {
            finish();
        });

        findViewById(R.id.ruleTime).setOnClickListener(v ->
                Toast.makeText(this, "Ra vào đúng giờ quy định của ký túc xá", Toast.LENGTH_SHORT).show()
        );

        findViewById(R.id.ruleClean).setOnClickListener(v ->
                Toast.makeText(this, "Giữ vệ sinh phòng ở và khu vực chung", Toast.LENGTH_SHORT).show()
        );

        findViewById(R.id.ruleGuest).setOnClickListener(v ->
                Toast.makeText(this, "Khách đến thăm cần đăng ký với ban quản lý", Toast.LENGTH_SHORT).show()
        );

        findViewById(R.id.ruleElectric).setOnClickListener(v ->
                Toast.makeText(this, "Không dùng thiết bị điện công suất lớn", Toast.LENGTH_SHORT).show()
        );

        findViewById(R.id.rulePayment).setOnClickListener(v ->
                Toast.makeText(this, "Thanh toán các khoản phí đúng hạn", Toast.LENGTH_SHORT).show()
        );
    }
}